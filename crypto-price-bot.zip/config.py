TRACKED_COINS = ["bitcoin", "ethereum", "ton"]
UPDATE_INTERVAL = 60  # в секундах