# 🤖 Crypto Price Bot

Бот на Python для отслеживания цены криптовалют с CoinGecko.

## 🚀 Запуск

```bash
pip install -r requirements.txt
python bot.py
```